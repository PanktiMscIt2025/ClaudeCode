SELECT b.name, COUNT(t.id) FROM branch b LEFT JOIN batch t ON t.branch_id = b.id GROUP BY b.name;
