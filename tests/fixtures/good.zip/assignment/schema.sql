CREATE TABLE branch (id INT PRIMARY KEY, name TEXT);
CREATE TABLE batch (id INT, branch_id INT REFERENCES branch(id), expiry DATE);
